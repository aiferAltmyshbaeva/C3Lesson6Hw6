package com.example.c3lesson6hw6

interface OnItemClickListener {
    fun onItemClick(position: Int)
}